/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientserver;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

/**
 *
 * @author yousha
 */
public class Client {

    public static void main(String dfs[]) throws IOException {

        String choice, filname;
        String res;
        FileReader fileReader;
        FileWriter fileWriter;

        BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));

        try (Socket clientSocket = new Socket("localhost", 6689)) {
            System.out.println("Attemp to connect to server  on port " + 6689);
            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Enter PUT for upload file to server, GET for get a file from server OR EXIT to exit");
            choice = br.readLine();
            while (true) {
                if (choice.equals("PUT")) {//if client choose upoload file
                    System.out.println("Enter file name you want to upload");
                    filname = br.readLine();//enter file name
                    //read content of file
                    fileReader = new FileReader("E:\\client\\" + filname);
                    BufferedReader brc = new BufferedReader(fileReader);
                    String content = new String();//contect of file
                    String line = null;
                    //read content of file
                    while ((line = brc.readLine()) != null) {
                        content += line;
                    }
                    //close file
                    fileReader.close();
                    //send choice
                    outToServer.writeBytes(choice + '\n');
                    //send file to upload
                    outToServer.writeBytes(filname + '\n');
                    //send content of file
                    outToServer.writeBytes(content + '\n');

                    //receive notification from server for complete operation
                    res = inFromServer.readLine();
                    System.out.println(res);
                } else //if client choose to download file
                if (choice.equals("GET")) {
                    System.out.println("Enter file name you wnat to get it ");
                    filname = br.readLine();//choose file name

                    //send to server choice and file name
                    outToServer.writeBytes(choice + '\n');
                    outToServer.writeBytes(filname + '\n');

                    //recieve response from server where res is the content of file
                    res = inFromServer.readLine();

                    //write content of downloaded file to clien's file at the same name
                    fileWriter = new FileWriter("E:\\client\\" + filname);
                    String temp = new String();
                    for (int i = 0; i < res.length(); i++) {
                        temp += res.charAt(i);
                    }
                    fileWriter.write(temp);
                    fileWriter.close();

                } else if (choice.equals("EXIT")) {
                    break;
                } else {
                    System.out.println("Invalid choice, valid choices are (GET,PUT,EXIT)");
                }
                System.out.println("Enter PUT for upload file to server, GET for get a file from server OR EXIT to exit");

                choice = br.readLine();
            }

        }

    }
}
