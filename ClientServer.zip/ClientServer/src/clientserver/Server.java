/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientserver;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;


public class Server {

    public static void main(String arg[]) throws IOException {

        String clientchoice;
        String clientFileName;

        FileWriter fileWriter;
        FileReader fileReader;

      
        System.out.println("server is up and running");
        ServerSocket welcomeSocket = new ServerSocket(6689);
        Socket connectionSocket = welcomeSocket.accept();
        while (true) {

            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));

            DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
            clientchoice = inFromClient.readLine();
            clientFileName = inFromClient.readLine();

            //if choice=PUT mean that client want to upload file
            if (clientchoice.equals("PUT")) {

                //recieve contect of file the user want to upload
                String content = inFromClient.readLine();

                fileWriter = new FileWriter("E:\\server\\" + clientFileName);

                //write content to file in the server at the same name
                String temp = new String();
                for (int i = 0; i < content.length(); i++) {
                    temp += content.charAt(i);

                }
                fileWriter.write(temp);
                fileWriter.close();

                //send response to server
                outToClient.writeBytes("uploaded sussefuly \n");
            } else //if client choose GET 
            if (clientchoice.equals("GET")) {

                String content = new String();
                fileReader = new FileReader("E:\\server\\" + clientFileName);
                BufferedReader brf = new BufferedReader(fileReader);
                String line = null;

                //read content of file
                while ((line = brf.readLine()) != null) {
                    content += line;
                }

                fileReader.close();

                outToClient.writeBytes(content + "\n");
            }

        }
    }
}
